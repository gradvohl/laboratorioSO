/*Lista de fun��es usadas nos threads */
void *sub_a(void *);
void *sub_b(void *);
