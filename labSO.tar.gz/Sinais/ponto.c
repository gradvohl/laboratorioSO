#include <stdio.h>

int main(int argc, char *argv[])
{
 while(1)
 {
    puts(".");
    sleep(1);
 }

 return 0;
}

